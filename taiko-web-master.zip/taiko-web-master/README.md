# taiko-web
A web-based Taiko no Tatsujin simulator.

Running instance: [https://taiko.bui.pm](https://taiko.bui.pm)

Still in development. Works best with Chrome.

## Setup
Please see the [Setup](https://github.com/bui/taiko-web/wiki/Setup) page for setup instructions.
